import HttpError from '@wasp/core/HttpError.js'

export const createConversation = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const newConversation = await context.entities.Conversation.create({
    data: {
      userId: context.user.id
    }
  });

  return newConversation;
}

export const createMessage = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }

  const conversation = await context.entities.Conversation.findUnique({
    where: { id: args.conversationId }
  });
  if (!conversation) { throw new HttpError(404) }

  if (conversation.userId !== context.user.id) { throw new HttpError(403) }

  return context.entities.Message.create({
    data: {
      content: args.content,
      isUser: args.isUser,
      conversation: { connect: { id: args.conversationId } }
    }
  });
}