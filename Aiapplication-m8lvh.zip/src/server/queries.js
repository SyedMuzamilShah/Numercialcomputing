import HttpError from '@wasp/core/HttpError.js'

export const getUserConversations = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }

  return context.entities.Conversation.findMany({
    where: { userId: context.user.id },
    include: { messages: true }
  })
}

export const getConversationMessages = async ({ conversationId }, context) => {
  if (!context.user) { throw new HttpError(401) }

  const conversation = await context.entities.Conversation.findUnique({
    where: { id: conversationId },
    include: { messages: true }
  })

  if (!conversation) { throw new HttpError(400, `Conversation with id ${conversationId} does not exist.`) }

  if (conversation.userId !== context.user.id) { throw new HttpError(400, `Conversation with id ${conversationId} does not belong to the authenticated user.`) }

  return conversation.messages;
}