import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useQuery } from '@wasp/queries';
import { useAction } from '@wasp/actions';
import getConversationMessages from '@wasp/queries/getConversationMessages';
import createMessage from '@wasp/actions/createMessage';

export function Conversation() {
  const { conversationId } = useParams();
  const { data: messages, isLoading, error } = useQuery(getConversationMessages, { conversationId });
  const createMessageFn = useAction(createMessage);
  const [newMessage, setNewMessage] = useState('');

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleCreateMessage = () => {
    createMessageFn({ conversationId, content: newMessage });
    setNewMessage('');
  };

  return (
    <div className=''>
      <div className=''>
        {messages.map((message) => (
          <div
            key={message.id}
            className=''
          >
            {message.content}
          </div>
        ))}
      </div>
      <div className=''>
        <input
          type='text'
          placeholder='New Message'
          className=''
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
        />
        <button
          onClick={handleCreateMessage}
          className=''
        >
          Send
        </button>
      </div>
      <Link to='/' className=''>Go back to Home</Link>
    </div>
  );
}