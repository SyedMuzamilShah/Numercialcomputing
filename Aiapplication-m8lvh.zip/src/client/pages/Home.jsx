import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@wasp/queries';
import { useAction } from '@wasp/actions';
import getUserConversations from '@wasp/queries/getUserConversations';
import createMessage from '@wasp/actions/createMessage';

export function HomePage() {
  const { data: conversations, isLoading, error } = useQuery(getUserConversations);
  const createMessageFn = useAction(createMessage);
  const [newMessage, setNewMessage] = useState('');

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleSendMessage = (conversationId) => {
    createMessageFn({ conversationId, content: newMessage });
    setNewMessage('');
  };

  return (
    <div>
      {/* Avatar and animations */}

      {/* Chatbot interface */}
      {conversations.map((conversation) => (
        <div key={conversation.id}>
          <h2>{conversation.title}</h2>
          {conversation.messages.map((message) => (
            <div key={message.id}>
              <p>{message.content}</p>
              <p>{message.isUser ? 'User' : 'System'}</p>
            </div>
          ))}
          <input
            type='text'
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
          />
          <button
            onClick={() => handleSendMessage(conversation.id)}
          >
            Send
          </button>
        </div>
      ))}

      {/* getUserConversations query and createMessage action */}
    </div>
  );
}